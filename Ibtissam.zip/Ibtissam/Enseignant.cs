﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ibtissam
{
    internal class Enseignant
    {
        internal class Enseignants
        {
            private int Enseignantid;
            private string Enom;
            private string Eprenom;
            private string Epassword;

            public int Enseignantid1 { get => Enseignantid; set => Enseignantid = value; }
            public string Enom1 { get => Enom; set => Enom = value; }
            public string Eprenom1 { get => Eprenom; set => Eprenom = value; }
            public string Epassword1 { get => Epassword; set => Epassword = value; }

        }
    }
}
