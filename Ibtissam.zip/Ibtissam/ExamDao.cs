﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Ibtissam.ModuleDao;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Ibtissam
{

    internal class ExamDao
    {
        string FileExam = "C:\\Users\\HP\\source\\repos\\Ibtissam\\exam.csv";
           


        public void AjouterExamen(Exam examen)
        {
            StreamWriter sw = new StreamWriter(FileExam, true);
            sw.WriteLine($"{examen.Etudiantid},{examen.Session},{examen.Matiere},{examen.Date:yyyy-MM-dd}");
            sw.Close();
        }

        public List<Exam> GetAllExamens()
        {
            List<Exam> examens = new List<Exam>();

            if (!File.Exists(FileExam)) return examens;

            StreamReader sr = new StreamReader(FileExam);
            string line;

            while ((line = sr.ReadLine()) != null)
            {
                string[] parts = line.Split(',');

                if (parts.Length == 4)
                {
                    Exam exam = new Exam
                    {
                        Etudiantid = int.Parse(parts[0]),
                        Session = parts[1],
                        Matiere = parts[2],
                        Date = DateTime.Parse(parts[3])
                    };

                    examens.Add(exam);
                }
            }

            sr.Close();
            return examens;
        }

        public List<Exam> RechercherParSession(string session)
        {
            List<Exam> resultats = new List<Exam>();
            List<Exam> tous = GetAllExamens();

            foreach (Exam e in tous)
            {
                if (e.Session.ToLower() == session.ToLower())
                {
                    resultats.Add(e);
                }
            }

            return resultats;
        }
    }
}
