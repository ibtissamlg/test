﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ibtissam
{
    internal class Admin
    {
        private int Administrateurid;
        private string Anom;
        private string Aprenom;
        private string Apassword;

        public int Administrateurid1 { get => Administrateurid; set => Administrateurid = value; }
        public string Anom1 { get => Anom; set => Anom = value; }
        public string Aprenom1 { get => Aprenom; set => Aprenom = value; }
        public string Apassword1 { get => Apassword; set => Apassword = value; }
    }

}

