﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ibtissam
{
    internal class AdminDao
    {
        string FileAdministrateur = "C:\\Users\\HP\\source\\repos\\Ibtissam\\Admin.csv";

        private string Anom;
        public void AddAdministrateur(int Administrateurid, string Anom, string Aprenom, string Apassword)
        {
            StreamWriter sw = new StreamWriter(FileAdministrateur, true);
            sw.WriteLine(Administrateurid + "," + Anom + "," + Aprenom + "," + Apassword);
            sw.Close();
        }

        public string[] FindAdministrateur(string nom, string password)
        {
            StreamReader sd = new StreamReader(FileAdministrateur);
            string line = sd.ReadLine();
            while (line != null)
            {
                string[] dd = line.Split(",");
                if (dd[1] == nom && dd[3] == password)
                {
                    sd.Close();
                    return dd;

                }
                line = sd.ReadLine();
            }
            sd.Close();
            return null;
        }
    }
}